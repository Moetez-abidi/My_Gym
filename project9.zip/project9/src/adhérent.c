#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "adhérent.h"

void ajouter_adherent (adherent s)
{

FILE* f;


f=fopen("adhrent.txt","a+");
if(f!=NULL){
fprintf(f,"%s %s %s %s %d %d %d %s %s %s %s %s %s %s \n",s.m,s.n,s.p,s.s,s.date.j,s.date.m,s.date.a,s.num,s.poid,s.add,s.hauteur,s.allergie,s.traitement,s.hism);
}fclose(f);
}
int verifier_adherent (adherent s)
{
FILE*f;
int t=0;
adherent s1;


f=fopen("adhrent.txt","r+");
if(f!=NULL){
while(fscanf(f,"%s %s %s %s %d %d %d %s %s %s %s %s %s %s \n",s1.m,s1.n,s1.p,s1.s,&s1.date.j,&s.date.m,&s.date.a,s1.num,s1.poid,s1.add,s1.hauteur,s1.allergie,s1.traitement,s1.hism)!=EOF){
if(strcmp(s1.m,s.m)==0){
t++;
break;
}
}
}fclose(f);





return t;
}





