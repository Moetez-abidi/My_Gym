#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utilisateur.h"
void ajouter_utilisateur (utilisateur u)
{

FILE* f;

if(strcmp(u.util,"Kinésitherapeute")==0){
f=fopen("kiné.txt","a+");
if(f!=NULL){
fprintf(f,"%s %s %s %s %d %d %d %s   \n",u.m,u.n,u.p,u.sexe,u.d.j,u.d.m,u.d.a,u.num);
}fclose(f);
}


 else if(strcmp(u.util,"medecin")==0){
f=fopen("medecin.txt","a+");
if(f!=NULL){
fprintf(f," %s %s %s %s %d %d %d %s \n",u.m,u.n,u.p,u.sexe,u.d.j,u.d.m,u.d.a,u.num);
}fclose(f);
}



else if(strcmp(u.util,"Diéteticient")==0){
f=fopen("ditéticient.txt","a+");
if(f!=NULL){
fprintf(f,"%s %s %s %s %d %d %d %s   \n",u.m,u.n,u.p,u.sexe,u.d.j,u.d.m,u.d.a,u.num);
}fclose(f);
}

   if(strcmp(u.util,"coachs")==0){
f=fopen("coach.txt","a+");
if(f!=NULL){
fprintf(f,"%s %s %s %s %d %d %d %s  \n",u.m,u.n,u.p,u.sexe,u.d.j,u.d.m,u.d.a,u.num);
}fclose(f);
}
}



int verifier_matricule (utilisateur u)
{
FILE*f;
int t=0;
utilisateur u1;

if(strcmp(u.util,"medecin")==0){
f=fopen("medecin.txt","r+");
if(f!=NULL){
while(fscanf(f,"%s %s %s %s %d %d %d %s   \n",u1.m,u1.n,u1.p,u1.sexe,&u1.d.j,&u1.d.m,&u1.d.a,u1.num)!=EOF){
if(strcmp(u1.m,u.m)==0){
t++;
break;
}
}
}fclose(f);
}

else if(strcmp(u.util,"Diéteticient")==0){
f=fopen("ditéticient.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s %s %s %d %d %d %s   \n",u1.m,u1.n,u1.p,u1.sexe,&u1.d.j,&u1.d.m,&u1.d.a,u1.num)!=EOF){
if(strcmp(u1.m,u.m)==0){
t++;
break;
}
}
}fclose(f);
}

else if(strcmp(u.util,"coachs")==0){
f=fopen("coach.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s %s %s %d %d %d %s   \n",u1.m,u1.n,u1.p,u1.sexe,&u1.d.j,&u1.d.m,&u1.d.a,u1.num)!=EOF){
if(strcmp(u1.m,u.m)==0){
t++;
break;
}
}
}fclose(f);
}

else if(strcmp(u.util,"Kinésitherapeute")==0){
f=fopen("kiné.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s %s %s %d %d %d %s   \n",u1.m,u1.n,u1.p,u1.sexe,&u1.d.j,&u1.d.m,&u1.d.a,u1.num)!=EOF){
if(strcmp(u1.m,u.m)==0){
t++;
break;
}
}
}fclose(f);
}

return t;
}



