#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "verife.h"
#include "utilisateur.h"
#include "adhérent.h"







void
on_button1_clicked                     (GtkButton       *object_graphique,//authentifiction
                                        gpointer         user_data)
{GtkWidget *window;
 GtkWidget *window1;
 GtkWidget *input;
 GtkWidget *output;
 FILE *f;
char login[20];char password[20];
char sorti[50];
int verif;
window1=lookup_widget(object_graphique,"window1");
input=lookup_widget(object_graphique,"entry1");
strcpy(login,gtk_entry_get_text(GTK_ENTRY(input)));
input=lookup_widget(object_graphique,"entry2");
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input)));
verif=verifier(login,password);
if (verif==1){gtk_widget_hide(window1);
window=create_admin();
gtk_widget_show_all(window);}
else if (verif==2){gtk_widget_hide(window1);
window=create_adherent();
gtk_widget_show_all(window);}

else if (verif==-1){strcpy(sorti,"nom d'utilisateur ou mot de pass incorrect");
output=lookup_widget(object_graphique,"label3");
gtk_label_set_text(GTK_LABEL(output),sorti); }
}











void
on_button2_clicked                     (GtkButton       *object_graphique,// bienvenu
                                        gpointer         user_data)
{GtkWidget *window3,*window4;
window3=lookup_widget(object_graphique,"admin");
gtk_widget_hide(window3);
window4=create_menu();
gtk_widget_show_all(window4);
}


void
on_button3_clicked                     (GtkButton       *object_graphique,//menu admin
                                        gpointer         user_data)
{
GtkWidget *window3,*window4;
window3=lookup_widget(object_graphique,"menu");
gtk_widget_hide(window3);
window4=create_employ__();
gtk_widget_show_all(window4);

}


void
on_button4_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data)
{GtkWidget *combo1,*combo2,*combo3,*combo4,*combo5,*matricule,*nom,*prenom,*jour,*mois,*anne,*numero,*homme,*femme,*valide,*output;//ajout 
utilisateur u ;
valide=create_valider();
combo1=lookup_widget(object_graphique, "combobox1");

output=lookup_widget(object_graphique,"label61");
jour=lookup_widget(object_graphique, "spinbutton1");
mois=lookup_widget(object_graphique, "spinbutton2");
anne=lookup_widget(object_graphique, "spinbutton3");

homme=lookup_widget(object_graphique,"radiobutton1");
femme=lookup_widget(object_graphique,"radiobutton2");
nom=lookup_widget(object_graphique, "entry4");
prenom=lookup_widget(object_graphique, "entry5");
matricule=lookup_widget(object_graphique,"entry3");
numero=lookup_widget(object_graphique, "entry6");

strcpy(u.util,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo1)));
strcpy(u.m,gtk_entry_get_text(GTK_ENTRY(matricule)));
strcpy(u.n,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(u.p,gtk_entry_get_text(GTK_ENTRY(prenom)));
u.d.j=gtk_spin_button_get_value(GTK_SPIN_BUTTON(jour));
u.d.a=gtk_spin_button_get_value(GTK_SPIN_BUTTON(anne));
u.d.m=gtk_spin_button_get_value(GTK_SPIN_BUTTON(mois));
strcpy(u.num,gtk_entry_get_text(GTK_ENTRY(numero)));
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(homme))){
strcpy(u.sexe,"M");
}
else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(femme))){
strcpy(u.sexe,"F");
}
if(strcmp(u.num,"0")==0){
gtk_label_set_text(GTK_LABEL(output),"Ce numéro est invalide!");
}
else if(strcmp(u.m,"")==0 ||strcmp(u.n,"")==0||strcmp(u.p,"")==0||strcmp(u.num,"")==0){
gtk_label_set_text(GTK_LABEL(output),"veuillez remplir toutes les cases");
}
 else if(verifier_matricule(u)==1){
gtk_label_set_text(GTK_LABEL(output),"ce matricule est déja utilisé");
}

else{
ajouter_utilisateur(u);
gtk_label_set_text(GTK_LABEL(output),"");
gtk_widget_show_all(valide);
}



}


void
on_button5_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data)
{

GtkWidget *ajout;
ajout=lookup_widget(object_graphique,"valider");
gtk_widget_hide(ajout);
}


void
on_button6_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data)
{GtkWidget *window3,*window4;
window3=lookup_widget(object_graphique,"menu");
gtk_widget_hide(window3);
window4=create_adhrent();
gtk_widget_show_all(window4);


}


void
on_button7_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data)
{

}


void
on_button8_clicked                     (GtkButton       *object_graphique,
                                        gpointer         user_data)
{GtkWidget *add,*po,*al,*h,*t,*hm,*matricule,*nom,*prenom,*jour,*mois,*anne,*numero,*homme,*femme,*va,*output1;// ajout adhrent
adherent s ;
va=create_valider();
output1=lookup_widget(object_graphique,"label62");
jour=lookup_widget(object_graphique, "spinbutton4");
mois=lookup_widget(object_graphique, "spinbutton5");
anne=lookup_widget(object_graphique, "spinbutton6");
add=lookup_widget(object_graphique, "entry18");
po=lookup_widget(object_graphique, "entry12");
al=lookup_widget(object_graphique, "entry14");
h=lookup_widget(object_graphique, "entry13");
t=lookup_widget(object_graphique, "entry15");
hm=lookup_widget(object_graphique, "entry16");
homme=lookup_widget(object_graphique,"radiobutton3");
femme=lookup_widget(object_graphique,"radiobutton4");
nom=lookup_widget(object_graphique, "entry7");
prenom=lookup_widget(object_graphique, "entry8");
matricule=lookup_widget(object_graphique,"entry19");
numero=lookup_widget(object_graphique, "entry11");

strcpy(s.add,gtk_entry_get_text(GTK_ENTRY(add)));
strcpy(s.poid,gtk_entry_get_text(GTK_ENTRY(po)));
strcpy(s.hauteur,gtk_entry_get_text(GTK_ENTRY(al)));
strcpy(s.allergie,gtk_entry_get_text(GTK_ENTRY(h)));
strcpy(s.traitement,gtk_entry_get_text(GTK_ENTRY(t)));
strcpy(s.hism,gtk_entry_get_text(GTK_ENTRY(hm)));
strcpy(s.m,gtk_entry_get_text(GTK_ENTRY(matricule)));
strcpy(s.n,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(s.p,gtk_entry_get_text(GTK_ENTRY(prenom)));
s.date.j=gtk_spin_button_get_value(GTK_SPIN_BUTTON(jour));
s.date.a=gtk_spin_button_get_value(GTK_SPIN_BUTTON(anne));
s.date.m=gtk_spin_button_get_value(GTK_SPIN_BUTTON(mois));
strcpy(s.num,gtk_entry_get_text(GTK_ENTRY(numero)));
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(homme))){
strcpy(s.s,"M");
}
else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(femme))){
strcpy(s.s,"F");
}
if(strcmp(s.num,"0")==0){
gtk_label_set_text(GTK_LABEL(output1),"Ce numéro est invalide!");
}
else if(strcmp(s.m,"")==0 ||strcmp(s.n,"")==0||strcmp(s.p,"")==0||strcmp(s.num,"")==0||strcmp(s.hism,"")==0||strcmp(s.add,"")==0||strcmp(s.hauteur,"")==0||strcmp(s.poid,"")==0||strcmp(s.allergie,"")==0||strcmp(s.traitement,"")==0||strcmp(s.hism,"")==0){
gtk_label_set_text(GTK_LABEL(output1),"veuillez remplir toutes les cases");
}
 else if(verifier_adherent(s)==1){
gtk_label_set_text(GTK_LABEL(output1),"ce matricule est déja utilisé");
}else{

ajouter_adherent (s);

gtk_widget_show_all(va);}

}

