typedef struct 
{
int j;
int m;
int a;
}da ;

typedef struct 
{

char m[20];
char n[20];
char p[20];
char s[20];
 da date;
char num[20];
char add[20];
char poid[20];
char hauteur[20];
char allergie[20];
char traitement[20];
char hism[20];
}adherent;

void ajouter_adherent(adherent s);
int verifier_adhrent(adherent s);
