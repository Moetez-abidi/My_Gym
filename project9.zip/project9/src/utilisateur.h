typedef struct 
{
int j;
int m;
int a;
}date ;

typedef struct 
{
char util[20];
char m[20];
char n[20];
char p[20];
char sexe[20];
 date d;
char num[20];
}utilisateur ;

void ajouter_utilisateur (utilisateur u);
int verifier_matricule (utilisateur u);

