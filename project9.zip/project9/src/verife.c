#include <stdio.h>
#include <string.h>
#include <verife.h>


int verifier (char login[], char password[]){
FILE *f;
char login1[20];char password1[20];
int role;int k=-1;

f=fopen("users.txt","r");//ouvertur du fichier en mode lecture
if(f !=NULL) {
     while(fscanf(f,"%s %s %d",login1,password1,&role)!=EOF){ //parcours du fichier
          if (strcmp(login, login1) == 0 ){
               if( strcmp(password, password1) == 0 ){
               k=role;
                                }
           } 
       }
}
fclose(f);
return k;
}
