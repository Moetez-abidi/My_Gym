typedef struct
{
	int jour;
	int mois;
	int annee;
}Date;
typedef struct
{
	Date dt_res;
	int ht_res;
}Reservation; 
int verifier_reserver(Reservation sa);
void reserver (Reservation s);
