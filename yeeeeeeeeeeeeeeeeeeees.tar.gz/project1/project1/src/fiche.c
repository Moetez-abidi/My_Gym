#include <stdio.h>
#include <string.h>
#include "fiche.h"
#include <gtk/gtk.h>



void ajouter_fiche(fiche fi)
{
	FILE *f;
	f=fopen("fiche.txt","a+");
	if(f!=NULL)
	{
	fprintf(f,"%s %s %s %s %s \n",fi.matricule,fi.imc,fi.proteines_necessaires,fi.img,fi.calories_necessaires);
	fclose(f);
	}
	}
	
void afficher_fiche(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	 char matricule[50];
	 char imc[20];
	 char proteines_necessaires[20];
	 char img[20];
	 char calories_necessaires[20];
	 store=NULL;
	 
	 FILE *f;
	 
	 store=gtk_tree_view_get_model(liste);
	 if(store==NULL)
	 {	
		 renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("matricule",renderer,"text",MATRICULE,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

                 renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("imc",renderer,"text",IMC,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		  renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("proteines_necessaires",renderer,"text",PRO,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		  renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("img",renderer,"text",IMG,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		  renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes("calories_necessaires",renderer,"text",CALORIES,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		 store=gtk_list_store_new (5, G_TYPE_STRING,G_TYPE_STRING , G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
		 f = fopen("fiche.txt","r");
		if(f!=NULL)
		{
		while(fscanf(f,"%s %s %s %s %s \n",matricule,imc,proteines_necessaires,img,calories_necessaires)!=EOF)
		{
		gtk_list_store_append(store,&iter);
        	gtk_list_store_set(store,&iter,MATRICULE,matricule,IMC,imc,PRO,proteines_necessaires,IMG,img,CALORIES,calories_necessaires,-1);
        		
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		g_object_unref(store);
		}
	 }
}
void modifier_fiche(char matricul[],char imce [],char proteines [],char imge [],char calories [])
{char matricule[50];
	char imc[20];
	char proteines_necessaires[20];
	char img[20];
	char calories_necessaires[20];
FILE* f;
FILE* m;
f=fopen("fiche.txt","r");
m=fopen("modif.txt","a+");
while(fscanf(f,"%s %s %s %s %s",matricule,imc,proteines_necessaires,img,calories_necessaires)!=EOF)
{if ((strcmp(matricule,matricul)==0))
    fprintf(m,"%s %s %s %s %s \n",matricul,imce,proteines,imge,calories);
else 
fprintf(m,"%s %s %s %s %s \n",matricule,imc,proteines_necessaires,img,calories_necessaires);
} 
fclose(f);
fclose(m);
rename("modif.txt","fiche.txt");
}
		 
