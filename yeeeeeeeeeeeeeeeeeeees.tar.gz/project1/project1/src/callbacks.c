#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "reservation.h"
#include "adherent.h"
#include "fiche.h"

void
on_button1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*output;
GtkWidget *window1;
window1=lookup_widget(button,"window1");
int trouve=0;
FILE*f;
char Username[20],Password[20],user[20],pass[20];
input1=lookup_widget(button,"entry1");
input2=lookup_widget(button,"entry2");
output=lookup_widget(button,"label22");

strcpy(Username,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(Password,gtk_entry_get_text(GTK_ENTRY(input2)));
f=fopen("user names.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s",user,pass)!=EOF){
if(strcmp(Username,user)==0 && strcmp(Password,pass)==0){
trouve++;
}
}
}fclose(f);
if(trouve==0){
gtk_label_set_text(GTK_LABEL(output),"nom d'utilisateur ou mot de passe incorrect");
gtk_entry_set_text(GTK_ENTRY(input2),"");
gtk_entry_set_text(GTK_ENTRY(input1),"");
}
else if(trouve!=0){
gtk_widget_hide(window1);
GtkWidget *window2;
window2 =create_window2 ();
gtk_widget_show (window2);
}
}

void
on_button2_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
window2=lookup_widget(button,"window2");
gtk_widget_hide(window2);
GtkWidget *window4;
window4 =create_window4 ();
gtk_widget_show (window4);





}


void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window2;
window2=lookup_widget(objet,"window2");
gtk_widget_hide(window2);
GtkWidget *window3;

window3 =create_window3 ();
gtk_widget_show (window3);
GtkWidget *treeview1;
treeview1=lookup_widget(window3,"treeview1");
afficher_adherent(treeview1);

}


void
on_button4_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
window2=lookup_widget(button,"window2");
gtk_widget_hide(window2);
GtkWidget *window1;
window1 =create_window1 ();
gtk_widget_show (window1);
}


void
on_button5_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *combobox1;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *label19;
Reservation s;

Date dt_res;
int ht_res;

combobox1=lookup_widget(objet_graphique,"combobox1");
jour=lookup_widget(objet_graphique,"spinbutton3");
mois=lookup_widget(objet_graphique,"spinbutton4");
annee=lookup_widget(objet_graphique,"spinbutton5");
label19=lookup_widget(objet_graphique,"label19");

dt_res.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
dt_res.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
dt_res.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

if(strcmp("9h ===> 12h" ,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)))==0)
	ht_res=1;
else
	ht_res=2;
s.dt_res=dt_res;
s.ht_res=ht_res;
if (!verifier_reserver (s))
{
	reserver(s);
	gtk_label_set_text(GTK_LABEL(label19),"Reservation réussite");
}
else
	gtk_label_set_text(GTK_LABEL(label19),"Date déjà reservée");

}


void
on_button6_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window4;
window4=lookup_widget(button,"window4");
gtk_widget_hide(window4);
GtkWidget *window2;
window2 =create_window2 ();
gtk_widget_show (window2);
}


void
on_button7_clicked                     (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window3;
window3=lookup_widget(button,"window3");
gtk_widget_hide(window3);
GtkWidget *window2;
window2 =create_window2 ();
gtk_widget_show (window2);
}


void
on_button8_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

fiche fi;
GtkWidget *input3,*input4,*input5,*input6,*input7;
GtkWidget *window5;

window5=lookup_widget(objet,"window5");

input3=lookup_widget(objet,"entry3");
input4=lookup_widget(objet,"entry4");
input5=lookup_widget(objet,"entry5");
input6=lookup_widget(objet,"entry6");
input7=lookup_widget(objet,"entry15");

strcpy(fi.matricule,gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(fi.imc,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(fi.proteines_necessaires,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(fi.img,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(fi.calories_necessaires,gtk_entry_get_text(GTK_ENTRY(input6)));

ajouter_fiche(fi);

}


void
on_button9_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window5;
GtkWidget *window6;

window5=lookup_widget(objet,"window5");
gtk_widget_destroy(window5);
window6=create_window6();
gtk_widget_show(window6);
GtkWidget *treeview2;
treeview2=lookup_widget(window6,"treeview2");
afficher_fiche(treeview2);
}



void
on_button10_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window5;
window5=lookup_widget(button,"window5");
gtk_widget_hide(window5);
GtkWidget *window3;
window3 =create_window3 ();
GtkWidget *treeview1;
treeview1=lookup_widget(window3,"treeview1");
gtk_widget_show (window3);

afficher_adherent(treeview1);

}




void
on_button12_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window6;
window6=lookup_widget(button,"window6");
gtk_widget_hide(window6);
GtkWidget *window5;
window5=create_window5 ();
gtk_widget_show (window5);
}



void
on_button15_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{

}


void
on_button16_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window7;
window7=lookup_widget(button,"window7");
gtk_widget_hide(window7);
GtkWidget *window6;
window6=create_window6 ();
GtkWidget *treeview2;
treeview2=lookup_widget(window6,"treeview2");
gtk_widget_show (window6);

afficher_fiche(treeview2);

}


void
on_button14_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{

/*char username[20];
fiche fi,fi2;
GtkWidget *IMC;
GtkWidget *Proteines_necessaires;
GtkWidget *IMG;
GtkWidget *Calories_necessaires;
GtkWidget *input1,*input2,*input3,*input4,*input5;
FILE*f1;
FILE*f2;
FILE*f3;


input1=lookup_widget(button,"entry7");
input2=lookup_widget(button,"entry8");
input3=lookup_widget(button,"entry9");
input4=lookup_widget(button,"entry10");
input5=lookup_widget(button,"entry14");

    	strcpy(username,gtk_entry_get_text(GTK_ENTRY(input5)));
	strcpy(fi2.imc,gtk_entry_get_text(GTK_ENTRY(input1)));
	strcpy(fi2.proteines_necessaires,gtk_entry_get_text(GTK_ENTRY(input2)));
	strcpy(fi2.img,gtk_entry_get_text(GTK_ENTRY(input3)));
	strcpy(fi2.calories_necessaires,gtk_entry_get_text(GTK_ENTRY(input4)));



f1=fopen("fiche.txt","r");
  if(f1!=NULL) 
  {
   while(fscanf(f1,"%s %s %s %s %s \n",fi.matricule,fi.imc,fi.proteines_necessaires,fi.img,fi.calories_necessaires)!=EOF)
{
f2=fopen("fiche.txt","r");
f3=fopen("fiche1.txt","a");
while(fscanf(f2,"%s %s %s %s %s \n",fi2.matricule,fi2.imc,fi2.proteines_necessaires,fi2.img,fi2.calories_necessaires)!=EOF) 
{
if (strcmp(fi.matricule,username)!=0) 
{
fprintf(f3,"%s %s %s %s %s \n",fi.matricule,fi.imc,fi.proteines_necessaires,fi.img,fi.calories_necessaires);
}
else {
fprintf(f3,"%s %s %s %s %s  \n",username,fi2.imc,fi2.proteines_necessaires,fi2.img,fi2.calories_necessaires);
}
}
fclose(f2);
fclose(f3);
remove("fiche.txt");
rename("fiche1.txt","fiche.txt");
 
}
fclose(f1);
}
*/
	char a[50];
	char b[20];
	char c[20];
	char d[20];
	char e[20];
GtkWidget *Matricule;
GtkWidget *IMC;
GtkWidget *Proteines_necessaires;
GtkWidget *IMG;
GtkWidget *Calories_necessaires;
GtkWidget *input1,*input2,*input3,*input4,*input5;
IMC=lookup_widget(button,"entry7");
Proteines_necessaires=lookup_widget(button,"entry8");
IMG=lookup_widget(button,"entry9");
Calories_necessaires=lookup_widget(button,"entry10");
Matricule=lookup_widget(button,"entry14");

        strcpy(a,gtk_entry_get_text(GTK_ENTRY(Matricule)));
	strcpy(b,gtk_entry_get_text(GTK_ENTRY(IMC)));
	strcpy(c,gtk_entry_get_text(GTK_ENTRY(Proteines_necessaires)));
	strcpy(d,gtk_entry_get_text(GTK_ENTRY(IMG)));
	strcpy(e,gtk_entry_get_text(GTK_ENTRY(Calories_necessaires)));
        modifier_fiche(a,b,c,d,e);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *MATRICULE;	
gchar *NOM; 
gchar *PRENOM;
gchar *JOUR;
gchar *MOIS;
gchar *ANNEE;
gchar *ADRESSE;
gchar *SEXE;
gchar *NUMERO;
GtkWidget *window3;
GtkWidget *window5;
GtkWidget *current;
GtkTreeIter iter;
GtkWidget *Matricule;
GtkWidget *Nom;
GtkWidget *Prenom;
GtkWidget *Jour;
GtkWidget *Mois;
GtkWidget *Annee;
GtkWidget *Adresse;
GtkWidget *Sexe;
GtkWidget *Numero;
window3=lookup_widget(treeview,"window3");
gtk_widget_hide(window3);
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&MATRICULE,1,&NOM,2,&PRENOM,3,&JOUR,4,&MOIS,5,&ANNEE ,6,&ADRESSE,7,&SEXE,8,&NUMERO,-1);}
window5 = create_window5();

Matricule=lookup_widget(window5,"entry15");
Nom=lookup_widget(window5,"label41");
Prenom=lookup_widget(window5,"label42");
Jour=lookup_widget(window5,"label49");
Mois=lookup_widget(window5,"label50");
Annee=lookup_widget(window5,"label51");
Adresse=lookup_widget(window5,"label52");
Sexe=lookup_widget(window5,"label53");
Numero=lookup_widget(window5,"label54");

gtk_entry_set_text(GTK_ENTRY(Matricule),MATRICULE);
gtk_label_set_text(GTK_LABEL(Nom),NOM);
gtk_label_set_text(GTK_LABEL(Prenom),PRENOM);
gtk_label_set_text(GTK_LABEL(Jour),JOUR);
gtk_label_set_text(GTK_LABEL(Mois),MOIS);
gtk_label_set_text(GTK_LABEL(Annee),ANNEE);
gtk_label_set_text(GTK_LABEL(Adresse),ADRESSE);
gtk_label_set_text(GTK_LABEL(Sexe),SEXE);
gtk_label_set_text(GTK_LABEL(Numero),NUMERO);

  gtk_widget_show (window5);
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *MATRICULE;
gchar *IMC;	
gchar *PRO; 
gchar *IMG;
gchar *CALORIES;

GtkWidget *window6;
GtkWidget *window7;
GtkWidget *current;
GtkTreeIter iter;
GtkWidget *Matricule;
GtkWidget *Imc;
GtkWidget *Proteines_necessaires;
GtkWidget *Img;
GtkWidget *Calories_necessaires;

window6=lookup_widget(treeview,"window6");
gtk_widget_hide(window6);
GtkTreeModel *model = gtk_tree_view_get_model(treeview);
if(gtk_tree_model_get_iter(model,&iter,path))
{gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&MATRICULE,1,&IMC,2,&PRO,3,&IMG,4,&CALORIES,-1);}
window7 = create_window7();

Matricule=lookup_widget(window7,"entry14");
Imc=lookup_widget(window7,"entry7");
Proteines_necessaires=lookup_widget(window7,"entry8");
Img=lookup_widget(window7,"entry9");
Calories_necessaires=lookup_widget(window7,"entry10");

gtk_entry_set_text(GTK_ENTRY(Matricule),MATRICULE);
gtk_entry_set_text(GTK_ENTRY(Imc),IMC);
gtk_entry_set_text(GTK_ENTRY(Proteines_necessaires),PRO);
gtk_entry_set_text(GTK_ENTRY(Img),IMG);
gtk_entry_set_text(GTK_ENTRY(Calories_necessaires),CALORIES);


  gtk_widget_show (window7);
}


void
on_button17_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window4;
window4=lookup_widget(button,"window4");
gtk_widget_hide(window4);
GtkWidget *window8;
window8=create_window8 ();
gtk_widget_show (window8);

}


void
on_button19_clicked                    (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window8;
window8=lookup_widget(button,"window8");
GtkWidget *input1,*input2,*input3,*output;
char confirm[20],newpass[20],oldpass[20],password[20],username[20];
FILE*f;

input1=lookup_widget(button,"entry11");
input2=lookup_widget(button,"entry12");
input3=lookup_widget(button,"entry13");
output=lookup_widget(button,"label71");

strcpy(oldpass,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(newpass,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(confirm,gtk_entry_get_text(GTK_ENTRY(input3)));

f=fopen("user names.txt","r");
	if(f!=NULL)
	{
		fscanf(f,"%s %s ",username, password);
		fclose(f);
	}



if(strcmp(newpass,confirm)==0 && strcmp(oldpass,password)==0)
{

	f=fopen("user names.txt","w");
	if(f!=NULL)
	{
		fprintf(f,"%s %s ",username, newpass);
		fclose(f);
	}

	gtk_label_set_text(GTK_LABEL(output),"Mot de passe mise à jour");
	gtk_entry_set_text(GTK_ENTRY(input1),"");
	gtk_entry_set_text(GTK_ENTRY(input2),"");
	gtk_entry_set_text(GTK_ENTRY(input3),"");

}
else 
{
	gtk_label_set_text(GTK_LABEL(output),"Erreur!,réessayer");
	gtk_entry_set_text(GTK_ENTRY(input1),"");
	gtk_entry_set_text(GTK_ENTRY(input2),"");
	gtk_entry_set_text(GTK_ENTRY(input3),"");

}
}


void
on_button18_clicked                    (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *window8;
window8=lookup_widget(button,"window8");
gtk_widget_hide(window8);
GtkWidget *window4;
window4=create_window4 ();
gtk_widget_show (window4);
}

