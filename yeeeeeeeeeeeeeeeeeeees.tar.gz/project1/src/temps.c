#include <stdio.h>
#include <string.h>
#include "temps.h"
#include <gtk/gtk.h>
#include "callbacks.h"


void afficher_temps(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	 char jour[20];
	 char mois[20];
	 char annee[20];
	 char heure[20];
	 store=NULL;
	 
	 FILE *f;
	 
	 store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
	 if(store==NULL)
	 {      
		 
	
		 
		  renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",JOUR,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" mois",renderer,"text",MOIS,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		
		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" annee",renderer,"text",ANNEE,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		 renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" heure",renderer,"text",HEURE,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		 renderer = gtk_cell_renderer_toggle_new ();
		column = gtk_tree_view_column_new_with_attributes(" select", renderer, "active",SELECTION, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		 
		 		 
		 store=gtk_list_store_new (5, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_BOOLEAN);
		f = fopen("temps.txt","r");
		if(f==NULL)
		{
			return;
		}
		else
		{f = fopen("temps.txt","a+");
		while(fscanf(f,"%s %s %s %s  \n",jour,mois,annee,heure)!=EOF)
		{
		gtk_list_store_append(store,&iter);
        gtk_list_store_set(store,&iter,JOUR,jour,MOIS,mois,ANNEE,annee,HEURE,heure,-1);
        		
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		g_signal_connect(G_OBJECT(renderer),"toggled", (GCallback)toggled_func,store);
		}
	 }
}
