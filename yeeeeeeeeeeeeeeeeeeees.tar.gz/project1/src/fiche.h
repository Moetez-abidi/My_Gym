#include <gtk/gtk.h>

typedef struct
{
	char matricule[50];
	char imc[20];
	char proteines_necessaires[20];
	char img[20];
	char calories_necessaires[20];
}fiche;

enum
{	MATRICULE,
	IMC,
	PRO,
	IMG,
	CALORIES,
};

void ajouter_fiche(fiche fi);
void afficher_fiche(GtkWidget *liste);
void modifier_fiche(char matricul[],char imce [],char proteines [],char imge [],char calories []);
void supprimer_fiche(char matricul[],char imce [],char proteines [],char imge [],char calories []);


