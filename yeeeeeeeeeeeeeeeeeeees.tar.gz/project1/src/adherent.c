#include <stdio.h>
#include <string.h>
#include "adherent.h"
#include <gtk/gtk.h>

enum	
{
	MATRICULE,
	NOM,
	PRENOM,
	JOUR,
	MOIS,
	ANNEE,
	ADRESSE,
	SEXE,
	NUMERO,
	
};

void afficher_adherent(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	 char matricule[20];
	 char nom[20];
	 char prenom [30];
	 char jour[20];
	 char mois[20];
	 char annee[20];
	 char adresse[20];
	 char sexe[20];
	 char numero[20];
	 store=NULL;
	 
	 FILE *f;
	 
	 store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
	 if(store==NULL)
	 {      
		 
		 renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" matricule",renderer,"text",MATRICULE,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		  renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",NOM,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		  renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" prenom",renderer,"text",PRENOM,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		  renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",JOUR,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" mois",renderer,"text",MOIS,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		
		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" annee",renderer,"text",ANNEE,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 

		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" adresse",renderer,"text",ADRESSE,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 		 

		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" sexe",renderer,"text",SEXE,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

		renderer=gtk_cell_renderer_text_new();
		 column=gtk_tree_view_column_new_with_attributes(" numero",renderer,"text",NUMERO,NULL);
		 gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
		 
		 		 
		 store=gtk_list_store_new (9, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
		f = fopen("adherent.txt","r");
		if(f==NULL)
		{
			return;
		}
		else
		{f = fopen("adherent.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s \n",matricule,nom,prenom,jour,mois,annee,adresse,sexe,numero)!=EOF)
		{
		gtk_list_store_append(store,&iter);
        gtk_list_store_set(store,&iter,MATRICULE,matricule,NOM,nom,PRENOM,prenom,JOUR,jour,MOIS,mois,ANNEE,annee,ADRESSE,adresse,SEXE,sexe,NUMERO,numero,-1);
        		
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
		
		}
	 }
}
