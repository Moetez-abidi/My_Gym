#include <stdio.h>

#include <stdlib.h>
#include <string.h>
#include "reservation.h"

int verifier_reserver(Reservation sa)
{
	Reservation s;
	int v=0;
	FILE* f=fopen("temps.txt","r");
	if (f!=NULL)
	{
		while(!v && fscanf(f,"%d %d %d %d ", &s.dt_res.jour , &s.dt_res.mois , &s.dt_res.annee ,&s.ht_res)!=EOF)
		{if ((s.dt_res.jour==sa.dt_res.jour) && (s.dt_res.mois==sa.dt_res.mois) && (s.dt_res.annee==sa.dt_res.annee) && (s.ht_res==sa.ht_res))
			{v=1;}
		}
	fclose(f);
	}
	return v;
}
void reserver (Reservation s)
{FILE* f=fopen("temps.txt","a");
	if (f!=NULL)
	{
		fprintf(f, "%d %d %d %d \n" ,s.dt_res.jour , s.dt_res.mois , s.dt_res.annee ,s.ht_res);
		fclose(f);
	}
	
}

