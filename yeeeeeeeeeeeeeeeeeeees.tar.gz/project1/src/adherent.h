#include <gtk/gtk.h>
 
 typedef struct
 {
	 char matricule[20];
	 char nom[20];
	 char prenom [30];
	 char jour[20];
	 char mois[20];
	 char annee[20];
	 char adresse[20];
	 char sexe[20];
	 char numero[20];
	 
 }Adherent;
 
 
 void afficher_adherent(GtkWidget *liste);

 
